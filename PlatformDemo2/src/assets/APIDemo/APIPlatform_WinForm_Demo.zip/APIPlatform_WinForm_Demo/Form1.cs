﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http.Formatting;
using System.Net.Http;
using System.Threading.Tasks;
using System.Configuration;

namespace APIPlatform_WinForm_Demo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string SecretId = ConfigurationManager.AppSettings["SecretId"]; 
            string SecretKey = ConfigurationManager.AppSettings["SecretKey"];
            string url = ConfigurationManager.AppSettings["GetProductFamilies"];

            System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
            
            client.DefaultRequestHeaders.Date = DateTime.Now;
            var dateString = client.DefaultRequestHeaders.GetValues("Date").FirstOrDefault();
            string source = "API Platform";
            //message.Headers.Add("date", dateString);
            client.DefaultRequestHeaders.Add("source", source);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"date:{dateString}");
            sb.AppendLine($"source:{source}");

            HMACSHA256 hmac = new HMACSHA256(Convert.FromBase64String(SecretKey));
            var signature = Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString())));
            sb.Clear();
            var authText = $"hmac id=\"{SecretId}\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\"{signature}\"";

            //var authText = $"hmac {secretId},{signature}";
            client.DefaultRequestHeaders.Authorization = System.Net.Http.Headers.AuthenticationHeaderValue.Parse(authText);

            var model = new getproductfamilymodel
            {
                Domain = "MES",
                UserName = "BCI",
                Password = "BCI",
                ProductArea = "Self-Adjusting Assembly Process_testing"
            };         
            var response = client.PostAsJsonAsync(url, model).Result;
            var result = response.Content.ReadAsStringAsync();//转成string
        }
        /// <summary>
        /// getproductfamilymodel is used to put in parameters
        /// </summary>
        public class getproductfamilymodel
        {
            public string Domain { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }
            public string ProductArea { get; set; }

        }

        private async void  button3_Click(object sender, EventArgs e)
        {

            //经API网关发布后的地址，可在API网关的管理页面查看，或者访问API 网关的路径/mes/routes获取
            //可在API Platform的Key Management页面 AppName,SecretId, SecretKey
            string SecretId = "V3p4JINyskSrwnH9ZV6TGg==";//"CAdk6/waqEy1IvAlW2yyNA==";
            string SecretKey = "2U/B/xXLS0Cle93oTuQuTPgcjuzjlkWB22kQi5qRIAA=";//"Asykh5N/BkKDHCP5uSraJ9GVMWaeZkGgcsula///8gA=";//
            var url = "http://10.8.186.225:8004/mes/l1013/SetupControl/api/Meta/Get";//"http://10.54.12.97:9996/mes/l1/PdaMda/api/Andon/GetAndonData";

            System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();
            HttpRequestMessage message = new HttpRequestMessage();
            message.RequestUri = new Uri(url);

            //var dateString = $"{DateTime.Now.ToUniversalTime():ddd, dd MMM yyyy hh:mm:ss} GMT";
            message.Headers.Date = DateTime.Now;
            var dateString = message.Headers.GetValues("Date").FirstOrDefault();
            string source = "API Platform";
            //message.Headers.Add("date", dateString);
            message.Headers.Add("source", source);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"date:{dateString}");
            sb.AppendLine($"source:{source}");

            HMACSHA256 hmac = new HMACSHA256(Convert.FromBase64String(SecretKey));
            var signature = Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString())));
            sb.Clear();
            var authText = $"hmac id=\"{SecretId}\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\"{signature}\"";

            //var authText = $"hmac {secretId},{signature}";
            message.Headers.Authorization = System.Net.Http.Headers.AuthenticationHeaderValue.Parse(authText);

            var response = await client.SendAsync(message);
            var text = await response.Content.ReadAsStringAsync();
            MessageBox.Show(text);


        }

        /// <summary>
        /// Post Method
        /// </summary>
        public void Post_Method()
        {
            //SecretId and SecretKey are the parts of authorization which can be found on API Platform 
            string SecretId = ConfigurationManager.AppSettings["SecretId"];
            string SecretKey = ConfigurationManager.AppSettings["SecretKey"];
            //url is the real request address of API which can be found on API Platform    
            string url = ConfigurationManager.AppSettings["GetProductFamilies"];

            //HttpClient is used to make a post request
            System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();

            //generate post authentication text
            client.DefaultRequestHeaders.Date = DateTime.Now;
            var dateString = client.DefaultRequestHeaders.GetValues("Date").FirstOrDefault();
            string source = ConfigurationManager.AppSettings["API Platform"]; 
            client.DefaultRequestHeaders.Add("source", source);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"date:{dateString}");
            sb.AppendLine($"source:{source}");
            HMACSHA256 hmac = new HMACSHA256(Convert.FromBase64String(SecretKey));
            var signature = Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString())));
            sb.Clear();           
            var authText = $"hmac id=\"{SecretId}\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\"{signature}\"";
            
            //fill authorization in request header
            client.DefaultRequestHeaders.Authorization = System.Net.Http.Headers.AuthenticationHeaderValue.Parse(authText);
            
            //contruct post request body content
            var model = new getproductfamilymodel
            {
                Domain = "MES",
                UserName = "BCI",
                Password = "BCI",
                ProductArea = "Self-Adjusting Assembly Process_testing"
            };

            //send post request and get response result
            var response = client.PostAsJsonAsync(url, model).Result;
            var result = response.Content.ReadAsStringAsync();
        }
        /// <summary>
        /// Get Method
        /// </summary>
        public async void Get_Method()
        {
            //SecretId and SecretKey are the parts of authorization which can be found on API Platform 
            string SecretId = ConfigurationManager.AppSettings["SecretId"];
            string SecretKey = ConfigurationManager.AppSettings["SecretKey"];
            //url is the real request address of API which can be found on API Platform    
            string url = ConfigurationManager.AppSettings["GetProductFamilies"];

            //HttpClient is used to make a post request
            System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();

            //create HttpRequestMessage
            HttpRequestMessage message = new HttpRequestMessage();
            message.RequestUri = new Uri(url);
            message.Headers.Date = DateTime.Now;
            var dateString = message.Headers.GetValues("Date").FirstOrDefault();
            string source = ConfigurationManager.AppSettings["API Platform"];
            message.Headers.Add("source", source);

            //generate get request signature and post authentication text
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"date:{dateString}");
            sb.AppendLine($"source:{source}");
            HMACSHA256 hmac = new HMACSHA256(Convert.FromBase64String(SecretKey));
            var signature = Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(sb.ToString())));
            sb.Clear();
            var authText = $"hmac id=\"{SecretId}\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\"{signature}\"";
            //fill authorization in request header
            message.Headers.Authorization = System.Net.Http.Headers.AuthenticationHeaderValue.Parse(authText);
            
            //send get request and get response result
            var response = await client.SendAsync(message);
            var text = await response.Content.ReadAsStringAsync();
        }



    }
}
