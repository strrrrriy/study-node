import { InjectionToken } from '@angular/core';

export const HIGHLIGHT_JS: InjectionToken<any> = new InjectionToken('highlight.js');