export * from './highlightJs.module';
export * from './highlightJs.token';