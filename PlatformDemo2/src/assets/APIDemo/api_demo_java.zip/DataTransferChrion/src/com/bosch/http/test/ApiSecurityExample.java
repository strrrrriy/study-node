package com.bosch.http.test;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

public class ApiSecurityExample {
	public static void main(String[] args) {
		try {
			 String source = "API Platform"; 
			 SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss");
//           sdf.setTimeZone(TimeZone.getTimeZone("GMT+8"));
	   	    Calendar beforeTime = Calendar.getInstance();
	   	    beforeTime.add(Calendar.HOUR, -8);// 2分钟之前的时间
	   		Date beforeD = beforeTime.getTime();
	   		String nowDate = sdf.format(beforeD);
           
           String dateString = nowDate.toString();
           dateString = "Mon, 04 Mar 2019 02:02:51";
			 StringBuilder sb = new StringBuilder();
	            sb.append("date:"+dateString+"").append("\r\n").append("source:"+source+"").append("\r\n");
	            System.out.println("sb : " + sb.toString());
			
			String secret = "Asykh5N/BkKDHCP5uSraJ9GVMWaeZkGgcsula///8gA=";
			String message = "API Platform";

			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
//			SecretKeySpec secret_key = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(Base64.decodeBase64(secret), "HmacSHA256");
			sha256_HMAC.init(secret_key);

			String hash = Base64.encodeBase64String(sha256_HMAC.doFinal("123456".toString().getBytes("UTF-8")));
			System.out.println(hash);
		} catch (Exception e) {
			System.out.println("Error");
		}
	}
}
