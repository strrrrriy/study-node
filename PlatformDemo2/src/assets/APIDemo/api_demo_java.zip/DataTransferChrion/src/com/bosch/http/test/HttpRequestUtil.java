package com.bosch.http.test;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;

import com.bosch.vo.Productfamily;
 

public class HttpRequestUtil {
	
	private static String secretId = "CAdk6/waqEy1IvAlW2yyNA==";
	private static String secretKey  = "paT";
	private static String postUrl = "http://10.54.12.97:9996/mes/l2/AccessControl/api/AccessControl/AuthenticateUser";
	
	private static String getUrl = "http://10.54.12.97:9996/mes/l2/SetupControl/api/Meta/Get";
	private static String source = "API Platform"; 

	
	public static void main(String argus []) throws ParseException {
		System.out.println ("API Platform TEST for Get method !");
		
		Productfamily body = new Productfamily();
		body.setDomain("MES");
		body.setUserName("admin");
		body.setPassword("MES");
//		HttpRequestUtil.post(postUrl, body.toString());
		Scanner in = new Scanner(System.in);
		//输入Get Url
       /* System.out.println ("Please Input 'getUrl,secretId,secretKey,source':");
        String input = in.nextLine();
        System.out.println ("input : " + input);*/
        System.out.println ("Please Input the source name:");
        String source = in.nextLine();
        System.out.println ("Please Input the secretId:");
        String secretId = in.nextLine();
        System.out.println ("Please Input the secretKey:");
        String secretKey = in.nextLine();
        System.out.println ("Please Input the getUrl:");
        String url = in.nextLine();
        /*String[] arr = input.split(",");
        String url = arr[0].trim();
        System.out.println ("url : " + url);
        String secretId = arr[1].trim();
        System.out.println ("secretId : " + secretId);
        String secretKey = arr[2].trim();
        System.out.println ("secretKey : " + secretKey);
        String source = arr[3].trim();
        System.out.println ("source : " + source);*/
//        HttpRequestUtil.get(url);
		HttpRequestUtil.get(url, source, secretId, secretKey);
	}
	
    private static CloseableHttpClient httpClient;
    
    //构造HTTP Client
    static {
        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(100);
        cm.setDefaultMaxPerRoute(20);
        cm.setDefaultMaxPerRoute(50);
        httpClient = HttpClients.custom().setConnectionManager(cm).build();
    }
	
    /**
     * Http POST 请求
     * @param url - HTTP URL
     * @param jsonString - HTTP Body
     * @return
     * @throws ParseException
     */
	public static String post(String url, String jsonString) throws ParseException {
		
        CloseableHttpResponse response = null;
        String result = null;
        HttpEntity entity=null;
        try {
            HttpPost httpPost = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(30000).setConnectionRequestTimeout(30000).setSocketTimeout(30000).build();
            
            httpPost.setConfig(requestConfig);
            
            //获取格式化标准时间
            SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'");
    	    Calendar nowTime = Calendar.getInstance();
//    	    nowTime.add(Calendar.HOUR, -8);
    		Date nowDate = nowTime.getTime();
    		String nowDateString = sdf.format(nowDate);
            String dateString = nowDateString.toString();
            
            //构造StringBuilder
            StringBuilder sb = new StringBuilder();
            sb.append("date:"+dateString+"").append("\r\n").append("source:"+source+"").append("\r\n");
            System.out.println(sb.toString());
            
            //HmacSHA256加密
            Mac sha256_HMAC = null;
			try {
				sha256_HMAC = Mac.getInstance("HmacSHA256");
				SecretKeySpec secret_key = new SecretKeySpec(Base64.decodeBase64(secretKey), "HmacSHA256");
	            sha256_HMAC.init(secret_key);
			} catch (NoSuchAlgorithmException | InvalidKeyException e) {
				e.printStackTrace();
			}
            String signature = Base64.encodeBase64String(sha256_HMAC.doFinal(sb.toString().getBytes("UTF-8")));
            //构造authText
            String authText = "hmac id=\""+secretId+"\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\""+signature.replaceAll("\r\n", "")+"\"";
            
            //设置header
            httpPost.addHeader("Content-Type", "application/json");
            httpPost.addHeader("Authorization", authText);
            httpPost.addHeader("Date", dateString);
            httpPost.addHeader("source", source);
            httpPost.setEntity(new StringEntity(jsonString, Charset.forName("UTF-8")));
            response = httpClient.execute(httpPost);
            
            //获取返回状态
			if (response.getStatusLine().getStatusCode() == 200) {
				System.out.println(result + "-----------success------------------");
				entity =  response.getEntity();
		        result= EntityUtils.toString(entity, "UTF-8");
			} else {
				System.out.println(response.getStatusLine().getStatusCode() + "------------------fail-----------");
			}
            System.out.println("result : " + result);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != response) {
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }
	
	
	
	
	/**
     * Http GET 请求
     * @param url - HTTP URL
	 * @return
	 */
  /*  public static String get(String url) {
		
        CloseableHttpResponse response = null;
        String result = null;
        HttpEntity entity=null;
        try {
        	HttpGet httpGet = new HttpGet(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(30000).setConnectionRequestTimeout(30000).setSocketTimeout(30000).build();
            
            httpGet.setConfig(requestConfig);
            
            //获取格式化标准时间
            SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'");
    	    Calendar nowTime = Calendar.getInstance();
    	    nowTime.add(Calendar.HOUR, -8);
    		Date nowDate = nowTime.getTime();
    		String nowDateString = sdf.format(nowDate);
            String dateString = nowDateString.toString();
            
            //构造StringBuilder
            StringBuilder sb = new StringBuilder();
            sb.append("date:"+dateString+"").append("\r\n").append("source:"+source+"").append("\r\n");
            System.out.println(sb.toString());
            
            //HmacSHA256加密
            Mac sha256_HMAC = null;
			try {
				sha256_HMAC = Mac.getInstance("HmacSHA256");
				SecretKeySpec secret_key = new SecretKeySpec(Base64.decodeBase64(secretKey), "HmacSHA256");
	            sha256_HMAC.init(secret_key);
			} catch (NoSuchAlgorithmException | InvalidKeyException e) {
				e.printStackTrace();
			}
            String signature = Base64.encodeBase64String(sha256_HMAC.doFinal(sb.toString().getBytes("UTF-8")));
            //构造authText
            String authText = "hmac id=\""+secretId+"\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\""+signature.replaceAll("\r\n", "")+"\"";
            
            //设置header
            httpGet.addHeader("Content-Type", "application/json");
            httpGet.addHeader("Authorization", authText);
            httpGet.addHeader("Date", dateString);
            httpGet.addHeader("source", source);
            response = httpClient.execute(httpGet);
            
            //获取返回状态
			if (response.getStatusLine().getStatusCode() == 200) {
				System.out.println(result + "-----------success------------------");
				entity =  response.getEntity();
		        result= EntityUtils.toString(entity, "UTF-8");
			} else {
				System.out.println(response.getStatusLine().getStatusCode() + "------------------fail-----------");
			}

			System.out.println("result : " + result);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != response) {
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }
    */
    /**
     * Http GET 请求
     * @param url - HTTP URL
	 * @return
	 */
    public static String get(String url, String source, String secretId, String secretKey) {
		
        CloseableHttpResponse response = null;
        String result = null;
        HttpEntity entity=null;
        try {
        	HttpGet httpGet = new HttpGet(url);
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(30000).setConnectionRequestTimeout(30000).setSocketTimeout(30000).build();
            
            httpGet.setConfig(requestConfig);
            
            //获取格式化标准时间
            SimpleDateFormat sdf = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'");
    	    Calendar nowTime = Calendar.getInstance();
    	    nowTime.add(Calendar.HOUR, -8);
    		Date nowDate = nowTime.getTime();
    		String nowDateString = sdf.format(nowDate);
            String dateString = nowDateString.toString();
            
            //构造StringBuilder
            StringBuilder sb = new StringBuilder();
            sb.append("date:"+dateString+"").append("\r\n").append("source:"+source+"").append("\r\n");
            System.out.println(sb.toString());
            
            //HmacSHA256加密
            Mac sha256_HMAC = null;
			try {
				sha256_HMAC = Mac.getInstance("HmacSHA256");
				SecretKeySpec secret_key = new SecretKeySpec(Base64.decodeBase64(secretKey), "HmacSHA256");
	            sha256_HMAC.init(secret_key);
			} catch (NoSuchAlgorithmException | InvalidKeyException e) {
				e.printStackTrace();
			}
            String signature = Base64.encodeBase64String(sha256_HMAC.doFinal(sb.toString().getBytes("UTF-8")));
            //构造authText
            String authText = "hmac id=\""+secretId+"\", algorithm=\"hmac-sha256\", headers=\"date source\", signature=\""+signature.replaceAll("\r\n", "")+"\"";
            
            //设置header
            httpGet.addHeader("Content-Type", "application/json");
            httpGet.addHeader("Authorization", authText);
            httpGet.addHeader("Date", dateString);
            httpGet.addHeader("source", source);
            response = httpClient.execute(httpGet);
            
            //获取返回状态
			if (response.getStatusLine().getStatusCode() == 200) {
				System.out.println(result + "-----------success------------------");
				entity =  response.getEntity();
		        result= EntityUtils.toString(entity, "UTF-8");
			} else {
				System.out.println(response.getStatusLine().getStatusCode() + "------------------fail-----------");
			}

			System.out.println("result : " + result);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != response) {
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }
    
    
}