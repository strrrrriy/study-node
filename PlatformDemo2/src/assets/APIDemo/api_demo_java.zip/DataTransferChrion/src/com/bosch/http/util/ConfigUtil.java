package com.bosch.http.util;

import java.io.UnsupportedEncodingException;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

/**
 * @描述: 获取项目资源文件工具类 .
 * @作者: yiqiuheng .
 * @创建时间: 2016-3-15,下午9:43:52 .
 * @版本: 1.0 .
 */
public class ConfigUtil {  
    private static PropertiesConfiguration  config=null;  
    static{  
        try{  
            config = new PropertiesConfiguration();  
            config.setEncoding("UTF-8");  
            config.load("config.properties");  
        }catch(ConfigurationException ex){  
        	ex.printStackTrace();
        }  
    }  
      
    /** 
     * 功能描述：获取配置文件参数值 ,统一返回字符串类型
     * @param str(参数KEY值)
     * @return String
     */  
    public static String getValue(String key) {  
        String s = config.getString(key);  
        try {  
            s = new String(s.getBytes("ISO8859-1"), "utf-8");  
        } catch (UnsupportedEncodingException e) {  
            e.printStackTrace();  
        }  
        return s;  
    }    
    
    /** 
     * 功能描述：获取配置文件参数值
     * @param str(参数KEY值)
     * @return int
     */ 
    public static int getIntValue(String key){  
        int reInt = 1;  
        try{  
            reInt = config.getInt(key);  
        }catch(Exception ex){  
            ex.fillInStackTrace();  
            reInt = 0;  
        }  
        return reInt;  
    }     
      
    /** 
     * 功能描述：获取配置文件参数值
     * @param str(参数KEY值)
     * @return Long
     */ 
    public static Long getLongValue(String key) {  
        Long reLong = 1l;  
        try{  
            reLong = config.getLong(key);  
        }catch(Exception ex){  
            ex.fillInStackTrace();  
            reLong = 0l;  
        }  
        return reLong;  
    }  
      
    /** 
     * 功能描述：获取配置文件参数值
     * @param str(参数KEY值)
     * @return double
     */ 
    public static double getDoubleValue(String key){  
        double reDouble = 1.0;  
        try{  
            reDouble = config.getDouble(key);  
        }catch(Exception ex){  
            ex.fillInStackTrace();  
            reDouble =1.0;  
        }  
        return reDouble;  
    }  
      
    /** 
     * 功能描述：获取配置文件参数值
     * @param str(参数KEY值)
     * @return Boolean
     */ 
    public static Boolean getBooleanValue(String key) {  
        Boolean flag = false;  
        try{  
            flag = config.getBoolean(key);
        }catch(Exception ex){  
            ex.fillInStackTrace();  
        }  
        return flag;  
    }  
      
    /** 
     * 功能描述：获取指定配置文件参数的值 
     * @param strPropertiesFile(配置文件名称) 
     * @param strItem(参数名称) 
     * @return String
     */  
    public static String getPropertiesValue(String strPropertiesFile, String strItem) {  
        String strItemValue = "";  
        ResourceBundle resources = null;  
        try {  
            resources = ResourceBundle.getBundle(strPropertiesFile);  
            strItemValue = resources.getString(strItem);  
        } catch (MissingResourceException e) {  
            e.printStackTrace(); 
        }  
        return strItemValue;
    }  
      
}  