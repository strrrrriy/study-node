package com.bosch.http.util;

public class DataTypeUtils {

	
	/**
	 * 将int类型转换为4位的byte
	 * @param num
	 * @return
	 */
    public static byte[] int2bytes(int num) {  
	    byte[] b = new byte[4];  
	    int mask = 0xff;  
	    for (int i = 0; i < 4; i++) {  
	        b[i] = (byte) (num >>> (24 - i * 8));  
	    }  
	    return b;  
	} 
    
    /**
     * 将2个byte数组合并
     * @param byte_1 headLength
     * @param byte_2 body
     * @return
     */
    public static byte[] byteMerger(byte[] byte_1, byte[] byte_2){  
        byte[] byte_3 = new byte[byte_1.length+byte_2.length];  
        System.arraycopy(byte_1, 0, byte_3, 0, byte_1.length);  
        System.arraycopy(byte_2, 0, byte_3, byte_1.length, byte_2.length);  
        return byte_3;  
    }  
}
