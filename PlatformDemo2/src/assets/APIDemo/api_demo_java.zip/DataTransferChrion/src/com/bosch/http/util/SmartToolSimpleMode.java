package com.bosch.http.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.bosch.vo.SmartToolSimplePo;

public class SmartToolSimpleMode {

	private static final Logger logger = Logger.getLogger(SmartToolSimpleMode.class);
	
//	static boolean alarm = false;
	static int AC1 = 10;
	static int AC2 = 70;

	static int n = 1;

	static int minRtl = 0;
	
//	Logger logger = Logger.getLogger(SmartToolSimpleDAOImpl.class);

//	@Resource(name = "sessionFactory")
//	private SessionFactory sessionFactory;

	public static List<SmartToolSimplePo> updateTable1(List<SmartToolSimplePo> smartToolSimpleList) {
		boolean alarm = false;
		
		// 测试，data应该会转换为SmartToolSimplePo的集合 //
		// List<SmartToolSimplePo> smartToolSimpleList = new
		// ArrayList<SmartToolSimplePo>();
//		List<SmartToolSimplePo> smartToolSimpleList = readCsv("C:\\Data\\012-RBCD\\Chiron\\SmartToolChange\\Simple\\smart1.csv");
//		List<SmartToolSimplePo> smartToolSimpleList = getResponseHttpBody(data);

		// Get min(RTL)
		minRtl = getMinRtl(smartToolSimpleList);

		logger.info("minRtl : " + minRtl);

		for (SmartToolSimplePo simplePo : smartToolSimpleList) {
			simplePo.setRemCycVal(minRtl - AC1 + "");
			int rtl = simplePo.getRtl();
//			logger.info("rtl : " + rtl);
			int stl = simplePo.getStl();
			if (rtl <= AC2) {
				simplePo.setSimuAbnormalChangeFlag(true);
			} else {
				simplePo.setSimuAbnormalChangeFlag(false);
			}

			if (rtl >= 0.5 * stl) {
				simplePo.setReusability(true);
			} else {
				simplePo.setReusability(false);
			}

			if (rtl <= (minRtl - AC1 + AC2)) {
				simplePo.setSimuNormalChangeFlag(true);
			} else {
				simplePo.setSimuNormalChangeFlag(false);
			}

			if (minRtl <= AC1) {
				alarm = true;
			} else {
				alarm = false;
			}

			// Re-use临时货架库存量 N>=n,需要实现临时货架规则
			int N = getReuseTempInventoryByType(simplePo.getPreSettingNo());

			if (N >= n) {
				simplePo.setReuseAvailable(true);
			} else {
				simplePo.setReuseAvailable(false);
			}

			int whichToolHaveProbelm = simplePo.getWhichToolHaveProblem();
			if (whichToolHaveProbelm == 4 || whichToolHaveProbelm == 5 || whichToolHaveProbelm == 6
					|| whichToolHaveProbelm == 7) {
				simplePo.setAbnormal(true);
			}
			if (whichToolHaveProbelm == 1 || whichToolHaveProbelm == 2 || whichToolHaveProbelm == 3 || whichToolHaveProbelm == 0) {
				simplePo.setAbnormal(false);
			}
			if (whichToolHaveProbelm == 5) {
				simplePo.setWhichSpindleCanBeReused(2);
			} else if (whichToolHaveProbelm == 6) {
				simplePo.setWhichSpindleCanBeReused(1);
			} else {
				simplePo.setWhichSpindleCanBeReused(0);
			}

		} // Update Table1

		
		logger.info("########################Table1#####################################");
		
		logger.info("productType,machineNo,preSettingNo,toolInfo,"
				+ "rtl,stl,toolChangeReason,whichToolHaveProblem,"
				+ "reCount,abnormal,simuNormalChangeFlag,simuAbnormalChangeFlag,"
				+ "reusability,reuseAvailable,whichSpindleCanBeReused");
		
		for (SmartToolSimplePo po : smartToolSimpleList) {
			logger.info(po.getProductType() + " , " + po.getMachineNo() + " , " + po.getPreSettingNo() + " , " + po.getToolInfo() + 
					" , " + po.getRtl() + " , " + po.getStl() + " , " + po.getToolChangeReason() + " , " + po.getWhichToolHaveProblem() + 
					" , " + po.getReCount() + " , " + po.isAbnormal() + " , " + po.isSimuNormalChangeFlag() + " , " + po.isSimuAbnormalChangeFlag() + 
					" , " + po.isReusability() + " , " + po.isReuseAvailable() + " , " + po.getWhichSpindleCanBeReused());
		}
		
		return updateTable2(smartToolSimpleList);
		
		
	}

	public static List<SmartToolSimplePo> updateTable2(List<SmartToolSimplePo> smartToolSimpleList) {

		List<SmartToolSimplePo> smartToolTable2 = new ArrayList<SmartToolSimplePo>();
		List<SmartToolSimplePo> smartToolTable3 = new ArrayList<SmartToolSimplePo>();

		// 是否有刀具abnormal?根据ToolChangeReason判断
		if (ifHaveAbnormal(smartToolSimpleList)) {
			for (SmartToolSimplePo simplePo : smartToolSimpleList) {
				if (simplePo.isSimuAbnormalChangeFlag() || simplePo.isAbnormal()) {
					if(!ifContainTool(smartToolTable2,simplePo.getPreSettingNo())) {
						simplePo.setRemCycVal("0");
						smartToolTable2.add(simplePo);
					}
				}
				if(simplePo.getWhichSpindleCanBeReused() != 0 && simplePo.isReusability()) {
					smartToolTable3.add(simplePo);
				}
			}
			// Send to Rexroth:smartToolTable2
			// Write table2 to Table3(临时货架库存)
		} else {
			for (SmartToolSimplePo simplePo : smartToolSimpleList) {
				if (simplePo.isSimuNormalChangeFlag()) {
					if(!ifContainTool(smartToolTable2,simplePo.getPreSettingNo())) {
						smartToolTable2.add(simplePo);
					}
				}
			}
			// Send to Rexroth:smartToolTable2
		}
		
		logger.info("########################Table2#####################################");
		
		logger.info("productType,machineNo,preSettingNo,toolInfo,"
				+ "rtl,stl,toolChangeReason,whichToolHaveProblem,"
				+ "reCount,abnormal,simuNormalChangeFlag,simuAbnormalChangeFlag,"
				+ "reusability,reuseAvailable,whichSpindleCanBeReused");
		
		for (SmartToolSimplePo po : smartToolTable2) {
			logger.info(po.getProductType() + " , " + po.getMachineNo() + " , " + po.getPreSettingNo() + " , " + po.getToolInfo() + 
					" , " + po.getRtl() + " , " + po.getStl() + " , " + po.getToolChangeReason() + " , " + po.getWhichToolHaveProblem() + 
					" , " + po.getReCount() + " , " + po.isAbnormal() + " , " + po.isSimuNormalChangeFlag() + " , " + po.isSimuAbnormalChangeFlag() + 
					" , " + po.isReusability() + " , " + po.isReuseAvailable() + " , " + po.getWhichSpindleCanBeReused());
		}
		
		logger.info("########################Table3#####################################");
		for (SmartToolSimplePo po : smartToolTable3) {
			logger.info(po.getProductType() + " , " + po.getMachineNo() + " , " + po.getPreSettingNo() + " , " + po.getToolInfo() + 
					" , " + po.getRtl() + " , " + po.getStl() + " , " + po.getToolChangeReason() + " , " + po.getWhichToolHaveProblem() + 
					" , " + po.getReCount() + " , " + po.isAbnormal() + " , " + po.isSimuNormalChangeFlag() + " , " + po.isSimuAbnormalChangeFlag() + 
					" , " + po.isReusability() + " , " + po.isReuseAvailable() + " , " + po.getWhichSpindleCanBeReused());
		}
		
		return smartToolTable2;

	}
	
	
	public static boolean ifContainTool(List<SmartToolSimplePo> smartToolTable2, String toolNo) {
		logger.info("toolNo : " + toolNo);
		for (SmartToolSimplePo simplePo : smartToolTable2) {
			if(simplePo.getPreSettingNo().equals(toolNo)) {
				return true;
			}
		}
		return false;
	}
	

	// 是否有刀具abnormal?根据ToolChangeReason判断,需要重写
	public static boolean ifHaveAbnormal(List<SmartToolSimplePo> smartToolSimpleList) {

		for (SmartToolSimplePo simplePo : smartToolSimpleList) {
			if (simplePo.isAbnormal()) {
				return true;
			}
		}
		return false;
	}

	// Re-use临时货架库存量N>=n？n=1
	public static int getReuseTempInventoryByType(String preSettingNo) {
		return 0;
	}

	public static int getMinRtl(List<SmartToolSimplePo> smartToolSimpleList) {
		int minRtl = Integer.MAX_VALUE;

		for (SmartToolSimplePo simplePo : smartToolSimpleList) {
			int rtl = simplePo.getRtl();
			if (rtl < minRtl) {
				minRtl = rtl;
			}
		}
		return minRtl;
	}

	public static void updateTable2Test(List<SmartToolSimplePo> smartToolSimpleList) {
		// Retrieve rows from table1 where ‘ToolType’ is the ‘ToolType’ value
		// where ‘Abnormal’ is ‘yes’ as table ‘Temp1’
		// 测试，data应该会转换为SmartToolSimplePo的集合
		List<SmartToolSimplePo> smartToolSimpleListTable2 = new ArrayList<SmartToolSimplePo>();

		Set<SmartToolSimplePo> temp1 = new HashSet<SmartToolSimplePo>();

		Set<String> toolTypeSet = new HashSet<>();

		for (SmartToolSimplePo simplePo : smartToolSimpleList) {
			/*
			 * if(simplePo.isAbnormalInput()) { temp1.add(simplePo);
			 * toolTypeSet.add(simplePo.getToolType()); }
			 */
		}

		for (SmartToolSimplePo simplePo : smartToolSimpleList) {
			/*
			 * if(toolTypeSet.contains(simplePo.getToolType())) {
			 * temp1.add(simplePo); }
			 */
		}

		for (SmartToolSimplePo simplePo : temp1) {
			/*
			 * if(!simplePo.isAbnormalInput() && simplePo.isReusability()) {
			 * //Update Table2 smartToolSimpleListTable2.add(simplePo); }
			 */
		}

		logger.info("########################updateTable2#####################################");

		for (SmartToolSimplePo po : smartToolSimpleListTable2) {
			// logger.info(po.getToolType() + ", " + po.getRtl() + ", " +
			// po.getStl() + ", " + po.getSpindle() + ", " +
			// po.isSimuNormalChangeFlag() + ", " +
			// po.isSimuAbnormalChangeFlag() + ", " + po.isReusability() + ", "
			// + po.isAbnormalInput());
		}
	}

	 public static List<SmartToolSimplePo> getResponseHttpBody(String receive) {

 		List<SmartToolSimplePo> simpleList = new ArrayList<>();

 		Document doc = null;
 		// 将字符串转为XML
 		try {
 			doc = DocumentHelper.parseText(receive);
 		} catch (DocumentException e1) {
 			// TODO Auto-generated catch block
 			e1.printStackTrace();
 		}
 		// 获取根节点
 		Element rootElt = doc.getRootElement();

 		// 获取根节点下的子节点head
 		Element header = rootElt.element("header");
 		// eventId
 		String eventId = header.attributeValue("eventId");
 		
 		String toolChangeTime = header.attributeValue("timeStamp");
 		
 		if(StringUtils.isNotEmpty(toolChangeTime) && toolChangeTime.length() >= 19 && toolChangeTime.indexOf("T") != -1) {
 			toolChangeTime = toolChangeTime.substring(0, 19).replace("T", " ");
 		}

 		Element location = header.element("location");
 		// machineNo
 		String machineNo = location.attributeValue("statNo");
 		// Body
 		Element body = rootElt.element("body");

 		// productType
 		String productType = body.element("structs").element("resHead").attributeValue("typeNo");

 		Element items = body.element("items");
 		
 		List<String> toolNameList = new ArrayList<>();
 		List<String> toolDesList = new ArrayList<>();
 		List<String> toolRemList = new ArrayList<>();
 		List<String> toolLifeList = new ArrayList<>();
 		List<Integer> toolHaveProblem = new ArrayList<>();
 		
 		
 		Iterator<Element> item = items.elementIterator(); 
 		
			while (item.hasNext()) {
				Element ele = item.next();
				String name = ele.attributeValue("name");
				if(name.startsWith("ToolDescrp")) {
					toolDesList.add(ele.attributeValue("value"));
				}
				if(name.startsWith("ToolMaxLife")) {
					String value = ele.attributeValue("value");
					if(value.indexOf(".") != -1) {
						toolLifeList.add(value.substring(0, value.indexOf(".")));
					} else {
						toolLifeList.add(value);
					}
				}
				if(name.startsWith("ToolRemLife")) {
					String value = ele.attributeValue("value");
					if(value.indexOf(".") != -1) {
						toolRemList.add(value.substring(0, value.indexOf(".")));
					} else {
						toolRemList.add(value);
					}
				}
				if(name.startsWith("ToolName")) {
					toolNameList.add(ele.attributeValue("value"));
				}
				if(name.startsWith("ToolStatus")) {
					toolHaveProblem.add(Integer.parseInt(ele.attributeValue("value")));
				}
			}
 		
 		for (int i = 0; i < toolDesList.size(); i++) {
 			
 			if(Integer.parseInt(toolLifeList.get(i)) == 0 || Integer.parseInt(toolLifeList.get(i)) == 99999) {
 				continue;
 			}
 			
//     		logger.info("toolNameList.get(i) : " + toolNameList.get(i));
 			if(toolNameList.get(i).equals("") || toolNameList.get(i) == null) {
 				continue;
 			}
 			
 			String toolInfoArr = toolDesList.get(i);
 			String tool1 = toolInfoArr.substring(0,11);
 			String tool2 = toolInfoArr.substring(11);
 			
//     		logger.info("i : " + i);
 			SmartToolSimplePo simplePo = new SmartToolSimplePo();
 			simplePo.setProductType(productType);
 			simplePo.setMachineNo(machineNo);
 			simplePo.setPreSettingNo(toolNameList.get(i));
 			simplePo.setToolInfo(tool1);
 			simplePo.setRtl(Integer.parseInt(toolRemList.get(i)));
 			simplePo.setStl(Integer.parseInt(toolLifeList.get(i)));
 			simplePo.setWhichToolHaveProblem(toolHaveProblem.get(i));
 			simplePo.setToolChangeTime(toolChangeTime);
 			simpleList.add(simplePo);
 			
 			try {
					SmartToolSimplePo simplePo2 = (SmartToolSimplePo) simplePo.clone();
					if(!tool2.equals("") && tool2 != null) {
						simplePo2.setToolInfo(tool2);
	        			simpleList.add(simplePo2);
	    			}
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
 			
 			
 		}
 		
 		logger.info("########################Table0#####################################");
 		
 		logger.info("productType,machineNo,preSettingNo,toolInfo,"
 				+ "rtl,stl,toolChangeReason,whichToolHaveProblem,"
 				+ "reCount,abnormal,simuNormalChangeFlag,simuAbnormalChangeFlag,"
 				+ "reusability,reuseAvailable,whichSpindleCanBeReused");
 		
 		for (SmartToolSimplePo po : simpleList) {
 			logger.info(po.getProductType() + " , " + po.getMachineNo() + " , " + po.getPreSettingNo() + " , " + po.getToolInfo() + 
 					" , " + po.getRtl() + " , " + po.getStl() + " , " + po.getToolChangeReason() + " , " + po.getWhichToolHaveProblem() + 
 					" , " + po.getReCount() + " , " + po.isAbnormal() + " , " + po.isSimuNormalChangeFlag() + " , " + po.isSimuAbnormalChangeFlag() + 
 					" , " + po.isReusability() + " , " + po.isReuseAvailable() + " , " + po.getWhichSpindleCanBeReused());
 		}
 		

 		return simpleList;
 	}

	public static List<SmartToolSimplePo> getResponseTable2(String receive) {
		
		 List<SmartToolSimplePo> simpleList = SmartToolSimpleMode.getResponseHttpBody(receive);
		 List<SmartToolSimplePo> table2 = SmartToolSimpleMode.updateTable1(simpleList);
		
		return table2;
	}

}
