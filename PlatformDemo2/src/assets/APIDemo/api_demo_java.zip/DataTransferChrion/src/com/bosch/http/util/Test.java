package com.bosch.http.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class Test {
	private static String secretId = "CAdk6/waqEy1IvAlW2yyNA==";
	private static String secretKey = "Asykh5N/BkKDHCP5uSraJ9GVMWaeZkGgcsula///8gA=";

	public static void main(String[] args) {
		try {
			String message = "Message";

			StringBuilder sb = new StringBuilder();
			sb.append("date:Fri, 01 Mar 2019 15:12:36 GMT").append("\r\n").append("source:API Platform").append("\r\n");

			Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
			SecretKeySpec secret_key = new SecretKeySpec(secretId.getBytes(), "HmacSHA256");
			sha256_HMAC.init(secret_key);

			String hash = Base64.encodeBase64String(sha256_HMAC.doFinal(message.getBytes()));
			System.out.println(hash);
		} catch (Exception e) {
			System.out.println("Error");
		}
	}
}
