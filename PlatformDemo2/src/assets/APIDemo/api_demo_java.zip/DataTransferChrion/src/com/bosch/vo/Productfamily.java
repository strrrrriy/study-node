package com.bosch.vo;

import net.sf.json.JSONObject;

public class Productfamily {

	private String Domain;
	private String UserName;
	private String Password;
	private String ProductArea;
	
	public String getDomain() {
		return Domain;
	}
	public void setDomain(String domain) {
		Domain = domain;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getProductArea() {
		return ProductArea;
	}
	public void setProductArea(String productArea) {
		ProductArea = productArea;
	}
	
	 public String toString(){
//	        return  "{\"Domain\":\""+this.getDomain()+"\",\"Password\":\""+this.getPassword()+"\",\"ProductArea\":\""+this.getProductArea()+"\",\"UserName\":\""+this.getUserName()+"\"}";

	        return  "{\"Domain\":\""+this.getDomain()+"\",\"Password\":\""+this.getPassword()+"\",\"UserName\":\""+this.getUserName()+"\"}";
	
	 }
	
}
