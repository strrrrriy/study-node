package com.bosch.vo;

public class SmartToolRes {
	
	private String machineNo;
	
	private String preSettingNo;
	
	private String remCycVal;
	
	private int rtl;
	
	private boolean reusability = false;
	
	private boolean reuseAvailable = false;
	
	private String batchNo;

	public String getMachineNo() {
		return machineNo;
	}

	public void setMachineNo(String machineNo) {
		this.machineNo = machineNo;
	}

	public String getPreSettingNo() {
		return preSettingNo;
	}

	public void setPreSettingNo(String preSettingNo) {
		this.preSettingNo = preSettingNo;
	}

	public String getRemCycVal() {
		return remCycVal;
	}

	public void setRemCycVal(String remCycVal) {
		this.remCycVal = remCycVal;
	}

	public int getRtl() {
		return rtl;
	}

	public void setRtl(int rtl) {
		this.rtl = rtl;
	}

	public boolean isReusability() {
		return reusability;
	}

	public void setReusability(boolean reusability) {
		this.reusability = reusability;
	}

	public boolean isReuseAvailable() {
		return reuseAvailable;
	}

	public void setReuseAvailable(boolean reuseAvailable) {
		this.reuseAvailable = reuseAvailable;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	
}
