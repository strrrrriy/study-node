package com.bosch.vo;

public class SmartToolSimplePo implements Cloneable{
	
	//typeNo 前四
	private String productType;
	
	//statNo
	private String machineNo;
	//ToolName
	private String preSettingNo;
	//ToolDescrp
	private String toolInfo;
	
	//ToolRemLife
	private int rtl;
	//ToolMaxLife
	private int stl;
	
	private String toolChangeReason;
	private int whichToolHaveProblem;
	private int reCount;
	
	private boolean abnormal;
	
	
	private boolean simuNormalChangeFlag = false;
	private boolean simuAbnormalChangeFlag = false;
	private boolean reusability = false;
	private boolean reuseAvailable = false;
	private int whichSpindleCanBeReused = 0;
	
	private String remCycVal;
	
	private String toolChangeTime;

	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getMachineNo() {
		return machineNo;
	}
	public void setMachineNo(String machineNo) {
		this.machineNo = machineNo;
	}
	public String getPreSettingNo() {
		return preSettingNo;
	}
	public void setPreSettingNo(String preSettingNo) {
		this.preSettingNo = preSettingNo;
	}
	public String getToolInfo() {
		return toolInfo;
	}
	public void setToolInfo(String toolInfo) {
		this.toolInfo = toolInfo;
	}
	public int getRtl() {
		return rtl;
	}
	public void setRtl(int rtl) {
		this.rtl = rtl;
	}
	public int getStl() {
		return stl;
	}
	public void setStl(int stl) {
		this.stl = stl;
	}
	public String getToolChangeReason() {
		return toolChangeReason;
	}
	public void setToolChangeReason(String toolChangeReason) {
		this.toolChangeReason = toolChangeReason;
	}
	public int getWhichToolHaveProblem() {
		return whichToolHaveProblem;
	}
	public void setWhichToolHaveProblem(int whichToolHaveProblem) {
		this.whichToolHaveProblem = whichToolHaveProblem;
	}
	public int getReCount() {
		return reCount;
	}
	public void setReCount(int reCount) {
		this.reCount = reCount;
	}
	public boolean isSimuNormalChangeFlag() {
		return simuNormalChangeFlag;
	}
	public void setSimuNormalChangeFlag(boolean simuNormalChangeFlag) {
		this.simuNormalChangeFlag = simuNormalChangeFlag;
	}
	public boolean isSimuAbnormalChangeFlag() {
		return simuAbnormalChangeFlag;
	}
	public void setSimuAbnormalChangeFlag(boolean simuAbnormalChangeFlag) {
		this.simuAbnormalChangeFlag = simuAbnormalChangeFlag;
	}
	public boolean isReusability() {
		return reusability;
	}
	public void setReusability(boolean reusability) {
		this.reusability = reusability;
	}
	public boolean isReuseAvailable() {
		return reuseAvailable;
	}
	public void setReuseAvailable(boolean reuseAvailable) {
		this.reuseAvailable = reuseAvailable;
	}
	public int getWhichSpindleCanBeReused() {
		return whichSpindleCanBeReused;
	}
	public void setWhichSpindleCanBeReused(int whichSpindleCanBeReused) {
		this.whichSpindleCanBeReused = whichSpindleCanBeReused;
	}
	public boolean isAbnormal() {
		return abnormal;
	}
	public void setAbnormal(boolean abnormal) {
		this.abnormal = abnormal;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	public String getRemCycVal() {
		return remCycVal;
	}
	public void setRemCycVal(String remCycVal) {
		this.remCycVal = remCycVal;
	}
	public String getToolChangeTime() {
		return toolChangeTime;
	}
	public void setToolChangeTime(String toolChangeTime) {
		this.toolChangeTime = toolChangeTime;
	}

}
